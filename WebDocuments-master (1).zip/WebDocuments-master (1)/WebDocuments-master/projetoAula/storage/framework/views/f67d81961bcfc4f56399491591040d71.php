<?php $__env->startSection('conteudo'); ?>
<h1>Lista de Usuários</h1>
<div class="table-responsive"> <table class="table table-striped"> <thead>
    <tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Login</th>
    <th>Senha</th>
    <th>Ações</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($usuario->id); ?></td>
    <td><?php echo e($usuario->nome); ?></td>
    <td><?php echo e($usuario->login); ?></td>
    <td><?php echo e($usuario->senha); ?></td>
    <td>
        <a class="btn btn-warning" href="<?php echo e(route('usuario.atualiza', ['id' => $usuario->id])); ?>">Alterar</a>
        <a class="btn btn-danger" href="#" onclick="exclui(<?php echo e($usuario->id); ?>)">Excluir</a> 
        <a class="btn btn-success" href="<?php echo e(route('venda.usuario', ['id' => $usuario->id])); ?>"> Vendas </a>
        </td> </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            <a class="btn btn-primary" href="<?php echo e(route('usuarios.cadastro')); ?>"> Cadastrar Novo </a>
</div>
<script>
    function exclui(id) {
        if (confirm('Deseja excluir o usuário de id: ' + id + '?')) {
            location.href = '/usuario/excluir/' + id;
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ifsc\Downloads\WebDocuments-master (1)\WebDocuments-master\projetoAula\resources\views/usuarios/index.blade.php ENDPATH**/ ?>
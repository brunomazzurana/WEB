<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Venda extends Model
{
    use HasFactory;

    protected $table = "venda";

    protected $primaryKey = 'id';

    function usuario(){
        return $this->belongsTo('App\Models\usuario', 'id_usuario', 'id');
    }
}
